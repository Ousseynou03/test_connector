rootProject.name = "http-connector-for-apache-kafka"
